/******************************************************************************
 * Program:   EEGsource.EXE                                                   *
 * Module:    NeuroscanADC.h                                                  *
 * Comment:   Definition for the GenericADC class (Neuroscan version)         *
 * Version:   1.0a                                                            *
 * Author:    Gerwin Schalk / David J. Weston                                 *
 * Copyright: (C) Wadsworth Center, NYSDOH / IACS, University of Warwick, UK  *
 ******************************************************************************
 * Version History:                                                           *
 *                                                                            *
 * V1.0a - 07/09/2003 - Modified RandomNumber data acquistion module to accept*
 *                      EEG source data from Scan software (Neuroscan Inc.)   *
 ******************************************************************************/
//---------------------------------------------------------------------------//---------------------------------------------------------------------------

#ifndef NeuroscanADC_7H
#define NeuroscanADC_7H
//---------------------------------------------------------------------------
#endif

#include "GenericADC.h"

class NeuroscanADC : public GenericADC
{
public:
                NeuroscanADC();
    virtual     ~NeuroscanADC();

    virtual void Preflight( const SignalProperties&, SignalProperties& ) const;
    virtual void Initialize();
    virtual void Process( const GenericSignal*, GenericSignal* );
    virtual void Halt();

protected:
        PARAMLIST       *paramlist;
        STATELIST       *statelist;
        short           DCoffset;
        bool            modulateamplitude;
        char            multstate[256];
        int   samplerate;
        int   blocksize;
        int   channels;
        int startflag;
};
