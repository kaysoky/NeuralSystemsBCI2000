/******************************************************************************
 * Program:   EEGSource.EXE                                                   *
 * Module:    Neuroscan.CPP                                                   *
 * Comment:   The EEGsource module for BCI2000 (Neuroscan version)            *
 * Version:   1.0a                                                            *
 * Author:    Gerwin Schalk / David J. Weston                                 *
 * Copyright: (C) Wadsworth Center, NYSDOH / IACS, University of Warwick, UK  *
 ******************************************************************************
 * Version History:                                                           *
 *                                                                            *
 * V1.0a - 07/09/2003 - Modified RandomNumber data acquistion module to accept*
 *                      EEG source data from Scan software (Neuroscan Inc.)   *
 ******************************************************************************/
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USEFORM("..\UMain.cpp", fMain);
USEFORM("..\..\shared\UVisConfig.cpp", fVisConfig);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->Title = "EEGsource V1.0a";
                 Application->CreateForm(__classid(TfMain), &fMain);
                 Application->CreateForm(__classid(TfVisConfig), &fVisConfig);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------


