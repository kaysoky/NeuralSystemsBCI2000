//  Two-dimensional movement for using thumb movement to move the cursor to 
//  the right and middle finger movement to move the cursor down.


/*--------------------------------------------------------------------------*/
// A simple cross-platform console application to test the glove
//
// WIN32 must be defined when compiling for Windows.
// For Visual C++ this is normally already defined.
//
// Copyright (C) 2000, 5DT <Fifth Dimension Technologies>
/*--------------------------------------------------------------------------*/
#include "fglove.h"
#include <stdio.h>
#include <string.h>
#ifdef WIN32
#include <windows.h> // for Sleep
#else
#include <unistd.h>  // for usleep
#endif
/*--------------------------------------------------------------------------*/
int main( int argc, char** argv )
{
	char    *szPort    = NULL;
	fdGlove *pGlove    = NULL;
	bool     showraw   = false;
	int      glovetype = FD_GLOVENONE;
	int      i;

	szPort = "COM1";

	// Initialize glove
	printf( "Attempting to open glove on %s .. ", szPort );
	if (NULL == (pGlove = fdOpen( szPort )))
	{
		printf( "failed.\n" );
		return -1;
	}
	printf( "succeeded.\n" );

	char *szType = "?";
	glovetype = fdGetGloveType(pGlove);
	switch (glovetype)
	{
	case FD_GLOVENONE: szType = "None"; break;
	case FD_GLOVE7:    szType = "Glove7"; break;
	case FD_GLOVE7W:   szType = "Glove7W"; break;
	case FD_GLOVE16:   szType = "Glove16"; break;
	case FD_GLOVE16W:  szType = "Glove16W"; break;
	}
	printf( "glove type: %s\n", szType );
	printf( "glove handedness: %s\n", fdGetGloveHand(pGlove)==FD_HAND_RIGHT?"Right":"Left" );
	int iNumSensors = fdGetNumSensors(pGlove);
	printf( "glove num sensors: %d\n", iNumSensors );
	// Display glove info
	unsigned char buf[64];
	fdGetGloveInfo( pGlove, buf );
	printf( "glove info: %s\n", (char*)buf );
	
	float thumb;
	float prevthumb=0;
	float index;
	float previndex=0;
	float x=33;
	float y=0;
	for ( i=0; i<1000; i++ )
	{
		index = fdGetSensorScaled(pGlove,FD_MIDDLENEAR); //Get middle finger data
		if (index>.7 & previndex<.7) y=y-1;  // move down if finger movement
		if (index>.5 & previndex<.5) y=y-1;
		if (index<.1 & previndex<.1) y=y+.05;  // move up if finger unflexed
		if (y>12) y=12;
		if (y<-10) y=-10;
		
		thumb = fdGetSensorScaled(pGlove,FD_THUMBNEAR); //Get thumb data
		if (thumb>.5 & prevthumb<.5) x=x+2;  // move right if thumb movement
		if (thumb>.3 & prevthumb<.3) x=x+2;
		if (thumb<.1 & prevthumb<.1) x=x-.15;   // move left if thumb unflexed
		if (x>75) x=75;
		if (x<0) x=0;
		
		previndex=index;
		prevthumb=thumb;
				
		for(int m=0; m<25; m++) printf("\n");	
		
		for(int k=0; k<x; k++) printf(" ");   // print x number of spaces
				
		printf("X\n");
		for(int j=0; j<10+y; j++) printf("\n");	
				
#ifdef WIN32
		Sleep(15);
#else
		usleep(15000); // fixme
#endif
	}

	// Close glove
	printf( "closing glove\n" );
	fdClose( pGlove );
	printf( "glove closed, goodbye\n" );

	return 0;
}
/*--------------------------------------------------------------------------*/