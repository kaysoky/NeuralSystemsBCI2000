// Writes the raw data to a file.  The data ranges from 0 (unflexed) to 4080 (flexed).

/*--------------------------------------------------------------------------*/
// A simple cross-platform console application to test the glove
//
// WIN32 must be defined when compiling for Windows.
// For Visual C++ this is normally already defined.
//
// Copyright (C) 2000, 5DT <Fifth Dimension Technologies>
/*--------------------------------------------------------------------------*/
#include "fglove.h"
#include <stdio.h>
#include <string.h>
#ifdef WIN32
#include <windows.h> // for Sleep
#else
#include <unistd.h>  // for usleep
#endif
/*--------------------------------------------------------------------------*/
int main( int argc, char** argv )
{
	char    *szPort    = NULL;
	fdGlove *pGlove    = NULL;
	bool     showraw   = false;
	int      glovetype = FD_GLOVENONE;
	int      i;

	szPort = "COM1";

	// Initialize glove
	printf( "Attempting to open glove on %s .. ", szPort );
	if (NULL == (pGlove = fdOpen( szPort )))
	{
		printf( "failed.\n" );
		return -1;
	}
	printf( "succeeded.\n" );

	char *szType = "?";
	glovetype = fdGetGloveType(pGlove);
	switch (glovetype)
	{
	case FD_GLOVENONE: szType = "None"; break;
	case FD_GLOVE7:    szType = "Glove7"; break;
	case FD_GLOVE7W:   szType = "Glove7W"; break;
	case FD_GLOVE16:   szType = "Glove16"; break;
	case FD_GLOVE16W:  szType = "Glove16W"; break;
	}
	printf( "glove type: %s\n", szType );
	printf( "glove handedness: %s\n", fdGetGloveHand(pGlove)==FD_HAND_RIGHT?"Right":"Left" );
	int iNumSensors = fdGetNumSensors(pGlove);
	printf( "glove num sensors: %d\n", iNumSensors );
	// Display glove info
	unsigned char buf[64];
	fdGetGloveInfo( pGlove, buf );
	printf( "glove info: %s\n", (char*)buf );
	
	FILE *stream;
	stream  = fopen( "rawdata.txt", "w" );     //File name is rawdata.txt
	fprintf(stream, "thumb index mid ring little \n");
	for ( i=0; i<1000; i++ )
	{
		
				fprintf(stream, "%4d ", (int)fdGetSensorRaw(pGlove,FD_THUMBNEAR));  // Get raw data and write to file
				fprintf(stream,  "%4d ", (int)fdGetSensorRaw(pGlove,FD_INDEXNEAR));
				fprintf(stream,  "%4d ", (int)fdGetSensorRaw(pGlove,FD_MIDDLENEAR));
				fprintf(stream,  "%4d ", (int)fdGetSensorRaw(pGlove,FD_RINGNEAR));
				fprintf(stream,   "%4d \n", (int)fdGetSensorRaw(pGlove,FD_LITTLENEAR));
	
#ifdef WIN32
		Sleep(15);
#else   
		usleep(15000); // fixme
#endif
	}
fclose( stream );
	// Close glove
	printf( "closing glove\n" );
	fdClose( pGlove );
	printf( "glove closed, goodbye\n" );

	return 0;
}
/*--------------------------------------------------------------------------*/